#include "UserInterface.h"
#include "Game.h"
#include <stdlib.h>
#include <iostream>


int main() {
	const auto mapName = UserInterface::selectMap();
	const auto nPlayers = UserInterface::selectNumPlayers();
	
	Game game(mapName, nPlayers);

	//tests part 2. Edits to Country,Player and Game.
	vector<Player> p = game.getTurns();

	for (int i = 0; i < p.size(); i++)
	{
		cout<<p[i].getID()<<endl;
	}
	cout << "Player a countries: " << endl;
	p[0].countries();
    


	return 0;

}