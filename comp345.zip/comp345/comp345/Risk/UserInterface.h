#pragma once

#include <string>

class UserInterface {
public:
	static std::string selectMap();
	static int selectNumPlayers();
};
